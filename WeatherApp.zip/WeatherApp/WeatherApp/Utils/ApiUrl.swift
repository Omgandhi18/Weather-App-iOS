//
//  ApiUrl.swift
//  WeatherApp
//
//  Created by Athulya Tech on 7/18/23.
//

import Foundation

var BASEURL = "http://192.168.29.79:81"

class API_URL: NSObject{
    //----Login----
    static let LoginURL                     = BASEURL + "/api/LoginAPI/UserLogin"
    //http://192.168.29.79:81/api/LoginAPI/UserLogin
}
