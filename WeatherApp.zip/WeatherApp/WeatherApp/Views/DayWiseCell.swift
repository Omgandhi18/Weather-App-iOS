//
//  DayWiseCell.swift
//  WeatherApp
//
//  Created by Athulya Tech on 7/18/23.
//

import UIKit

class DayWiseCell: UICollectionViewCell {
    @IBOutlet weak var lblTemp: UILabel!
    @IBOutlet weak var lblDate: UILabel!
    @IBOutlet weak var lblHigh: UILabel!
    @IBOutlet weak var lblLow: UILabel!
    
}
